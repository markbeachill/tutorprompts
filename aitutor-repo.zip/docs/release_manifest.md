# AI Personal Tutor Toolkit — release manifest

Toolkit release: Site v4.2.1 / Prompt libraries v4.2.1 / Testing pack v4.2.1

This manifest describes the current public site package after the v4.2.1 WT4 answer-boundary patch.

## Repository-level developer files

- `README.md` — repository introduction and live site link
- `BUILD_AND_GENERATOR_GUIDE.md` — consolidated library/page build workflow
- `PACKAGE_GENERATOR_START_HERE.md` — quick entry point to the generator guide
- `CUSTOMISING_PROMPTS.md` — interim guide for building smaller tailored libraries from the master library

## Publishing structure

The public GitHub Pages site is now contained in the `docs/` folder. GitHub Pages should be configured to publish from `main` / `docs`.

## Main site pages

- `docs/index.html` — homepage
- `docs/where-to-start/index.html` — expandable task-to-tool guide
- `docs/try-it/index.html` — canonical page for preloaded ChatGPT/Gemini tutor links
- `docs/tools/index.html` — collapsed table-based tools directory
- `docs/examples/index.html` — examples index
- `docs/student-help/index.html` — Student Help home
- `docs/guides/index.html` — Guides home
- `docs/download/index.html` — prompt-library and single-tool download page
- `docs/source-material/index.html` — copy-ready source material library, surfaced through Guides
- `docs/testing.html` — testing and audit page
- `docs/about.html` — About this site
- `docs/changelog/index.html` — public changelog

## Student Help pages

- `docs/student-help/students.html`
- `docs/student-help/student-ai-setup.html`
- `docs/student-help/directing-ai.html`
- `docs/student-help/writing-workflow.html`
- `docs/student-help/not-first-draft.html`
- `docs/student-help/free-tier.html`
- `docs/student-help/markdown.html`

## Guides and reference pages

- `docs/guides/teaching-approach.html`
- `docs/guides/why-educators.html`
- `docs/guides/tutors.html`
- `docs/guides/setup.html`
- `docs/guides/customising-prompts.html`
- `docs/guides/other-ai-tutoring-resources.html`

## Prompt-library downloads

Current public downloads are in:

- `docs/prompt-libraries/latest/`
- `docs/prompt-libraries/single-tools/`

Versioned prompt-library archives are in:

- `docs/prompt-libraries/v2.1/`
- `docs/prompt-libraries/v2.2/`
- `docs/prompt-libraries/v2.3/`
- `docs/prompt-libraries/v2.4/`
- `docs/prompt-libraries/v2.5/`
- `docs/prompt-libraries/v3.0/`
- `docs/prompt-libraries/v3.1/`
- `docs/prompt-libraries/v3.2/`
- `docs/prompt-libraries/v3.3/`
- `docs/prompt-libraries/v3.4/`
- `docs/prompt-libraries/v3.5/`
- `docs/prompt-libraries/v3.6/`
- `docs/prompt-libraries/v4.0/`
- `docs/prompt-libraries/v4.1/`
- `docs/prompt-libraries/v4.2/`
- `docs/prompt-libraries/v4.2.1/`

## Testing/audit downloads

Current public testing files are in:

- `docs/audit-library/latest/`

Versioned testing/audit archives are in:

- `docs/audit-library/v2.5/`
- `docs/audit-library/v2.6/`
- `docs/audit-library/v2.7/`
- `docs/audit-library/v2.8/`
- `docs/audit-library/v2.10/`
- `docs/audit-library/v3.0/`
- `docs/audit-library/v3.1/`
- `docs/audit-library/v3.2/`
- `docs/audit-library/v3.3/`
- `docs/audit-library/v3.4/`
- `docs/audit-library/v3.5/`
- `docs/audit-library/v4.0/`
- `docs/audit-library/v4.1/`
- `docs/audit-library/v4.2/`
- `docs/audit-library/v4.2.1/`

## Site v4.2.1 — WT4 answer-boundary patch

- Site package updated to v4.2.1.
- Prompt libraries updated to v4.2.1.
- Testing/audit pack updated to v4.2.1.
- Narrowed WT4 — Find My Mistakes so it checks writing mistakes, obvious everyday factual slips and visible technical referencing presentation slips only.
- Added audit guidance that marks WT4 down when it becomes a source-checker, evidence-checker, citation-substance checker or specialist subject-answering tool.
- Added a WT4 answer-boundary regression test card.

## Site v4.2 — Writing Tutor router, flow and subject tools

- Site package updated to v4.2.
- Prompt libraries updated to v4.2.
- Testing/audit pack updated to v4.2.
- Added WT1 — Which Writing Tool Should I Use? as a Writing Tutor routing helper.
- Renumbered the Writing Tutor family so the menu starts cleanly at WT1 and runs through WT10.
- Added WT9 — Flow and Coherence: The Running Subject.
- Added WT10 — Learn Subjects: Parsing Your Own Sentences.
- Updated the launcher/router, audit/testing pack, Tools page, Where to start? page, Examples index, Download page, Source material page, Testing page and Deployment check to match the v4.2 tool map.
- Added a compatibility note in the changelog because v4.2 changes the WT numbers used in older screenshots or teaching notes.

## Site v4.1 — WT7 paraphrase and quotation workshop

- Site package updated to v4.1.
- Prompt libraries updated to v4.1.
- Testing/audit pack updated to v4.1.
- Added WT7 — Paraphrase and Quotation Workshop to the Writing Tutor family.
- Rebuilt the master library, Writing Tutor mini-library, all mini-library archive outputs, custom packs and single-tool downloads.
- Added WT7 source-use testing cards for too-close paraphrase, plagiarism / patchwriting risk, quote framing and reporting-verb overclaiming.
- Updated the Tools directory, Writing Tutor page, single-tool download page, Testing page, release manifest, changelog and generated site data.

## Site v4.0 — prompt-library consolidation and testing-pack update

- Site package updated to v4.0.
- Prompt libraries updated to v4.0.
- Testing/audit pack updated to v4.0.
- Rebuilt the master library, five mini-libraries, custom pack and single-tool downloads from the v4.0 source split.
- Added the default teaching loop across the prompt-library source and clarified the positive learning behaviour behind academic-integrity boundaries.
- Updated launcher and router templates so students can describe their problem in one sentence and receive at most two tool suggestions before choosing.
- Updated testing/audit files with the output collector, long-input honesty checks, certainty/confidence/authority checks, WT1 sentence-movement checks and v4 tool-behaviour regression tests.
- Updated the Testing page, release metadata and public version labels to match the v4.0 downloads.

## v3.12 site update notes

- Site package updated to v3.12.
- Prompt libraries remain v3.6.
- Testing/audit pack remains v3.5.
- Added a single-tool downloads page at `docs/tools/single-tools.html` for free-tier AI users or tools with small upload/context limits.
- Added homepage and Tools directory links to the single-tool downloads route.
- No tutor prompt/source files, generated prompt-library outputs, generator scripts, GitHub workflows or testing/audit content changed.

## Detailed update notes

Detailed update notes are in:

- `docs/changelog/site-update-notes/`

## v2.21 housekeeping notes

- The repository root is now kept for repository-level files, especially `README.md`.
- The public site lives under `docs/`.
- Tool pages now live under `docs/tools/`.
- The examples page now lives under `docs/examples/`.
- The old root-level `changelog.html` compatibility page has been removed.
- Prompt-library and testing/audit behaviour did not change.

## v2.22 housekeeping notes

- Added root-level `PROMPTS.md` so developers can find the prompt libraries and understand the mini-library structure.
- Added root-level `CUSTOMISING_PROMPTS.md` with the interim “delete down from the master library” customisation method.
- Added a quiet public guide page at `docs/guides/customising-prompts.html` that points to the developer notes.
- Added an About page note for developers and departments.
- Prompt-library and testing/audit behaviour did not change.


## v2.23 housekeeping notes

- Updated the testing/audit pack to v2.9.
- Added two-chat audit workflow guidance, clearer rating boundaries, N/A evidence-table guidance, stronger SW3 testing, and a richer test log with AI tool/model and plan/access fields.
- Removed ambiguous version numbers from suggested test-output filenames and records versions in the test log instead.
- Improved the Examples page with more varied placeholder examples and a short dialogue example.
- Refined Student Help, Guides and Tools wording based on review feedback.
- Prompt-library behaviour did not change.


## v2.24 housekeeping notes

- Updated the prompt-library suite to v2.5.
- Changed visible file status in current prompt-library downloads from “working draft” to “active public release”.
- Added level, discipline and task calibration guidance to the global rules.
- Improved WT6 house-style fallback wording, added a WT3 worked correction-boundary example, and changed AT10 “random topic” wording to “useful starting point”.
- Rebuilt `docs/prompt-libraries/latest/`, `docs/prompt-libraries/v2.5/`, and the current mini-library ZIP downloads.
- Testing/audit pack remains v2.9.


## Site v2.25 — homepage and navigation polish; testing stress test

- Updated the homepage from the revised student-facing draft.
- Updated Student Help and Guides home pages from revised drafts.
- Simplified tool-detail pages using the Writing Tutor page as the model.
- Added a separate tool-code column to tool-detail tables.
- Updated the testing/audit pack to v2.10 with a deadline-pressure adversarial stress test.


## Site v3.0 — prompt-library v3.0 tutor-style revision

- Updated the prompt-library suite to v3.0.
- Added paragraph-first output guidance so student-facing feedback uses short, readable paragraphs by default and avoids unnecessary bullet overload.
- Added manageable-feedback guidance so tools focus on useful next moves rather than producing more feedback than the student can act on.
- Added the “I'm stuck” support model across libraries.
- Added “writing is thinking” as a guiding principle.
- Clarified the toolkit's scope as writing, revision, academic thinking, research planning and study workflow support rather than a general-purpose homework-answer system.
- Added plain-English grammar-term guidance for essential terms such as subject, verb and object.
- Rebuilt `docs/prompt-libraries/latest/`, `docs/prompt-libraries/v3.0/`, and the current mini-library ZIP downloads.
- Testing/audit pack remains v2.10.







## Site v3.11 — AI-literacy guidance, library sync and testing-pack hygiene

- Site package updated to v3.11.
- Prompt libraries updated to v3.5.
- Testing/audit pack updated to v3.5.
- Added Student Help guidance on using the toolkit repeatedly across a piece of work and staying in charge when AI output is imperfect.
- Added `docs/student-help/directing-ai.html` on learning to direct AI well.
- Added an AI-literacy argument to the educator guide.
- Added tutor guidance on setting honest expectations about AI behaviour and recommending the toolkit across the life of a project.
- Synchronised the master prompt library with the mini-libraries for WT1, ST1, AT1 and RP1.
- Rebuilt the current mini-library bundle and created a v3.5 prompt-library archive.
- Updated the step-by-step test cards to remove stale hard-coded audit-prompt filenames, rebuilt the testing pack and created a v3.5 testing/audit archive.

## Site v3.9 — Student Help structure fix

- Site package updated to v3.9.
- Prompt libraries remain v3.4.
- Testing/audit pack remains v3.4.
- Restored the main Student guide at `docs/student-help/students.html`.
- Moved the AI setup guidance from the former Student guide into `docs/student-help/student-ai-setup.html`.
- Updated the Student Help home page so the main Student guide is introduced as “What this is and how to get started.”

## Site v3.8 — AI setup and student setup guidance

- Site package updated to v3.8.
- Prompt libraries remain v3.4.
- Testing/audit pack remains v3.4.
- Replaced the placeholder setup page with a tutor guide on choosing and setting up an AI system for toolkit use.
- Added guidance that tutors should test planned classroom activities using the same or closest available setup students will use before asking students to use the toolkit.
- Added guidance on choosing or specifying thinking/reasoning models, free-plan limits, projects/workspaces and shared custom AIs/public GPTs.
- Simplified the Student guide so it focuses on experimenting with AI systems, choosing a suitable mode, managing free-plan usage and optional projects without repeating the toolkit instructions.

## Site v3.7 — teaching approach and student guide rewrite

- Site package updated to v3.7.
- Prompt libraries remain v3.4.
- Testing/audit pack remains v3.4.
- Rewrote the Teaching approach page around writing as thinking, ideas first, manageable feedback, “I’m stuck” support and development rather than completion.
- Rewrote the Student guide with a more direct paragraph-first style, clearer student benefits, simplified getting-started guidance, pushback guidance and privacy/responsibility notes.


## Site v3.6 — launcher minimum content and paragraph-first site design

- Site package updated to v3.5.
- Prompt libraries updated to v3.3.
- Testing/audit pack updated to v3.3.
- Added launcher minimum-content rules so AI models should not compress menus down to tool lists.
- Added testing/audit checks for launcher minimum content.
- Added a paragraph-first design rationale to the Teaching approach page and v3 design brief.
- Cleaned the Tools and Examples pages to align site structure with the paragraph-first design.

## Site v3.4 — startup activation and launcher fidelity

- Site package updated to v3.4.
- Prompt libraries updated to v3.2.
- Testing/audit pack updated to v3.2.
- Added a menu source rule so the launcher is the only source for menu output.
- Marked manifest and router sections as internal and not for output.
- Added visible tool-version headings such as `WT1 — Clarity Clinic v3.2`.
- Added visible current toolkit version notes near site downloads.
- Updated U6 to test startup activation and launcher fidelity.

## Site v3.3 — testing/audit v3 alignment

- Updated testing/audit pack to v3.0.
- Added audit checks for paragraph-first tutor style, manageable feedback, writing as thinking, plain-English grammar explanations and “I’m stuck” support.
- Added U5 “I’m stuck” support test and v3 regression cards.
- Rebuilt `docs/audit-library/latest/`, `docs/audit-library/v3.0/`, and the testing-pack ZIP downloads.
- Prompt libraries remain v3.0.

## Site v3.1 — site alignment with v3 tutor style

- Updated homepage and public site wording to present the toolkit as structured and specialist writing support, not only guardrails.
- Added clearer site guidance on writing as thinking, paragraph-first tutor style, manageable feedback and “I’m stuck” support.
- Updated Student Help, Teaching Approach, Educator and Tutor pages to reflect the v3 prompt-library principles.
- Prompt libraries remain v3.0 and testing/audit pack remains v2.10.
