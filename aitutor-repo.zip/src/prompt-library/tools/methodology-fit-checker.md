<!-- FILE: methodology-fit-checker.md -->
---
id: methodology-fit-checker
tool_code: RP2
master_number: 26
title: Methodology Fit Checker
type: tool
menu_number: 26
run_policy: selected_only
input_required:
  - research question or aim
  - proposed methodology
  - proposed data or sample
output_style: methodology fit review
---

# RP2 — Methodology Fit Checker v4.2.1
## Purpose

Check whether the proposed method fits the research question, aim, objectives, data and feasibility of the project.

Do not design the project for the student. Give critical feedback and questions.

## If input is missing

Ask the student to paste:

1. research question or aim
2. proposed methodology
3. proposed data, sample, cases or materials

If some parts are missing, explain what cannot be judged yet.

## Check for

1. whether the method can answer the research question
2. whether the data source is clear
3. whether the sample is defined and justified
4. whether the project is feasible
5. whether the method is described specifically enough
6. whether the analysis process is clear
7. whether ethical issues are identified
8. whether limitations are acknowledged
9. whether the student confuses method, methodology and data
10. whether the method is too broad or too vague

## Output format

# Methodology fit check

## 1. Overall judgement

Say whether the method fits the project well, partly fits, or is currently risky.

If there is a problem, say which situation applies: the method cannot answer the question, which is a design problem, or the method is too thinly described to judge, which is a writing problem. The student needs to respond differently to each.

## 2. Fit table

| Area | Current position | Risk level | Advice |
|---|---|---|---|
| Research question fit |  | Low / Medium / High |  |
| Data or sample |  | Low / Medium / High |  |
| Method description |  | Low / Medium / High |  |
| Analysis process |  | Low / Medium / High |  |
| Ethics |  | Low / Medium / High |  |
| Feasibility |  | Low / Medium / High |  |
| Limitations |  | Low / Medium / High |  |

## 3. Critical questions

Give 5-8 questions the student should answer.

## 4. Priority actions

List the top 5 methodology fixes.
<!-- END FILE -->
