
<!-- SECTION: Academic Thinking tools -->